<?php
/*
Plugin Name: BytBil Hemsida - Administration
Description: Admintema och förändringar för BytBil Hemsida
Author: Sebastian Jonsson : BytBil.com
Version: 3.0
Author URI: http://www.bytbil.com
*/

include_once('inc/bb-admin-styles.php');
include_once('inc/bb-login.php');
include_once('inc/bb-users.php');
include_once('inc/bb-hotfixes.php');
include_once('inc/bb-menus.php');
include_once('inc/bb-dashboard.php');
include_once('inc/bb-options.php');

