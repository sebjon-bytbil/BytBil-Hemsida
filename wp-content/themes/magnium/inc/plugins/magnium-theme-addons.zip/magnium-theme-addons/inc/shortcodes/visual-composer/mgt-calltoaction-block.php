<?php

// VC [calltoaction_block_wp]

vc_map(array(
   "name" 			=> "MGT Call To Action Block",
   "category" 		=> 'Magnium Content',
   "description"	=> "Block with Header, Text and Button",
   "base" 			=> "mgt_calltoaction_block_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_cta_block",
   
   "params" 	=> array(
   		array(
			"type"			=> "attach_image",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Background image",
			"param_name"	=> "background_image_id",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Background repeat",
			"param_name"	=> "background_repeat",
			"value"			=> array(
				"No repeat"	=> "no-repeat",
				"Repeat"	=> "repeat",
				"Repeat X"	=> "repeat-x",
				"Repeat Y"	=> "repeat-y"
			),
			"std"			=> "no-repeat",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Parallax effect",
			"description"	=> "Use background image with height few more than block height for correct parallax work",
			"param_name"	=> "parallax",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "colorpicker",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Background color",
			"param_name"	=> "background_color",
			"std"			=> "#EEEEEE",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Text color",
			"description"	=> "Use white color if you selected dark background color",
			"param_name"	=> "text_color",
			"value"			=> array(
				"Black"	=> "black",
				"White"	=> "white"
			),
			"std"			=> "black",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Title",
			"param_name"	=> "title",
			"std"			=> "Header",
		),
		array(
			"type"			=> "textarea_html",
			"holder"		=> "div",
			"class" 		=> "mgt-cta-block-content-html",
			"admin_label" 	=> false,
			"heading"		=> "Block text",
			"param_name"	=> "content",
			"std"			=> '',
		),
		array(
			"type"			=> "vc_link",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Button link",
			"description"	=> "Leave empty if you don't need button",
			"param_name"	=> "button_url",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button style",
			"param_name"	=> "button_style",
			"value"			=> array(
				"Bordered"	=> "bordered",
				"Default"	=> "solid",
				"Default invert"	=> "solid-invert",
				"Grey"	=> "grey",
				"Grey invert"	=> "grey-invert",
				"Red"	=> "red",
				"Green"	=> "green"
			),
			"description"	=> "Change button style",
			"std"			=> "solid",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button size",
			"param_name"	=> "button_size",
			"value"			=> array(
				"Small"	=> "small",
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button icon name",
			"description"	=> "If you want to add icon to button you can input Font Awesome icon name here, for example <em>angle-left</em>. <a href='http://fortawesome.github.io/Font-Awesome/icons/' target='_blank'>Check all available icons names</a>.",
			"param_name"	=> "button_icon",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Text size",
			"param_name"	=> "text_size",
			"value"			=> array(
				"Small"	=> "small",
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Text transform",
			"param_name"	=> "text_tranform",
			"value"			=> array(
				"None"	=> "none",
				"UPPERCASE"	=> "uppercase"
			),
			"description"	=> "",
			"std"			=> "none",
		),
		
   )

  
   
));