<?php

// Shortcode [post_list_wp]
function mgt_shortcode_post_list_wp($atts, $content = null) {
	extract(shortcode_atts(array(
		'block_size' => 'small', /* small, normal, medium, large */
		'animated' => 1,
		'use_slider' => 0,
		'slider_autoplay' => 0,
		'slider_navigation' => 0,
		'slider_pagination' => 1,
		'category' => '', /* Categories ID */
		'category_name' => '', /* Category name */
		'post_type' => 'post',
        'exclude' => '',
        'include' => '',
        'orderby' => 'name',
        'order' => 'ASC',
        'posts_per_page' => 9
	), $atts));
	ob_start();

	$args = array(
		'posts_per_page'   => $posts_per_page,
		'offset'           => 0,
		'category'         => $category,
		'category_name'    => $category_name,
		'orderby'          => $orderby,
		'order'            => $order,
		'include'          => $include,
		'exclude'          => $exclude,
		'meta_key'         => '',
		'meta_value'       => '',
		'post_type'        => $post_type,
		'post_mime_type'   => '',
		'post_parent'      => '',
		'post_status'      => 'publish',
		'suppress_filters' => true 
	);

	$posts = get_posts( $args );

	//print_r($posts);

	if(count($posts) == 1) {
		$single_post = ' mgt-single-post';
	} else {
		$single_post = '';
	}

	$rand_id = rand(1000,100000);

  	if($block_size == 'small') {
  		$image_size = 'mgt-post-image-small';
  		$slider_items = 4;
  	}
  	if($block_size == 'normal') {
  		$image_size = 'mgt-post-image-normal';
  		$slider_items = 3;
  	}
  	if($block_size == 'medium') {
  		$image_size = 'mgt-post-image-medium';
  		$slider_items = 2;
  	}
  	if($block_size == 'large') {
  		$image_size = 'mgt-post-image-large';
  		$slider_items = 1;
  	}

  	$style = '';

	if($use_slider == 1) {

		$style = ' style="display: none;"';

		if($slider_autoplay == 1) {
			$slider_autoplay = 'true';
		} else {
			$slider_autoplay = 'false';
		}
		if($slider_navigation == 1) {
			$slider_navigation = 'true';
		} else {
			$slider_navigation = 'false';
		}
		if($slider_pagination == 1) {
			$slider_pagination = 'true';
		} else {
			$slider_pagination = 'false';
		}

		echo '<div class="mgt-post-list-wrapper">';
	}
	
	if($animated == 1) {
		$add_class = ' animated';
	} else {
		$add_class = '';
	}

	echo '<div id="mgt-post-list-'.intval($rand_id).'" class="mgt-post-list'.esc_attr($single_post).' wpb_content_element'.esc_attr($add_class).'"'.$style.'>';

	$add_class = '';



	foreach($posts as $post) {

	  	echo '<div class="mgt-post '.esc_attr($block_size).'-blocks">';

	    $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), $image_size);

	    if(has_post_thumbnail( $post->ID )) {
	    	$image_bg ='background-image: url('.$image[0].');';
	    }
	    else {
	    	$image_bg = '';
	    }  	

	    $post_classes = get_post_class('', $post->ID);
		$post_format_class = $post_classes[4];
		


	  	echo '<a href="'.get_permalink($post->ID).'"><div class="mgt-post-image" data-style="'.esc_attr($image_bg).'"><div class="mgt-post-image-wrapper"></div></div></a><div class="mgt-post-details"><div class="mgt-post-icon '.esc_attr($post_format_class).'"></div><div class="mgt-post-title"><a href="'.get_permalink($post->ID).'"><h5>'.esc_html($post->post_title).'</h5></a></div><div class="mgt-post-date">'.get_the_time( get_option( 'date_format' ), $post->ID ).'</div></div>';

	    echo '</div>';
	} 

	echo '<div class="clearfix"></div>';
	echo '</div>';

	if($use_slider == 1) {
		echo '</div>';
	}

	if($use_slider == 1) {
		echo '<script>(function($){
	    $(document).ready(function() {

		    $("#mgt-post-list-'.intval($rand_id).'").owlCarousel({
	            items: '.esc_js($slider_items).',
	            itemsDesktop: [1024,3],
	            itemsTablet: [770,2],
	            itemsMobile : [480,1],
	            autoPlay: '.esc_js($slider_autoplay).',
	            navigation: '.esc_js($slider_navigation).',
	            navigationText : false,
	            pagination: '.esc_js($slider_pagination).',
	            afterInit : function(elem){
	                $(this).css("display", "block");
	            }
		    });
	    });})(jQuery);</script>';
	}

	wp_reset_query();

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("mgt_post_list_wp", "mgt_shortcode_post_list_wp");
