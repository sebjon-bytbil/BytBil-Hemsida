<?php

// VC [promo_block_wp]

vc_map(array(
   "name" 			=> "MGT Promo Block",
   "category" 		=> 'Magnium Content',
   "description"	=> "Block with content, background, fullwidth and parallax options",
   "base" 			=> "mgt_promo_block_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_promo_block",
   
   "params" 	=> array(
   		array(
			"type"			=> "attach_image",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Background image",
			"param_name"	=> "background_image_id",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Background repeat",
			"param_name"	=> "background_repeat",
			"value"			=> array(
				"No repeat"	=> "no-repeat",
				"Repeat"	=> "repeat",
				"Repeat X"	=> "repeat-x",
				"Repeat Y"	=> "repeat-y"
			),
			"std"			=> "no-repeat",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Parallax effect",
			"description"	=> "Use background image with height few more than block height for correct parallax work",
			"param_name"	=> "parallax",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Cover background image",
			"description"	=> "Background image will fit block by width (Not for parallax).",
			"param_name"	=> "coverimage",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "colorpicker",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Background color",
			"param_name"	=> "background_color",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Block width (px or %)",
			"description"	=> "Leave empty to use background image width",
			"param_name"	=> "block_width",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Block height (px or %)",
			"description"	=> "Leave empty to use background image height",
			"param_name"	=> "block_height",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Animate block on hover",
			"param_name"	=> "animated",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"description"	=> "Block background will fade to black on mouse hover",
			"std"			=> "1",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Semi-transparent dark content background",
			"param_name"	=> "darken",
			"value"			=> array(
				"Yes"	=> "darken",
				"No"	=> "no-darken"
			),
			"description"	=> "Use this option if you have light background image and want to show light text on it",
			"std"			=> "darken",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Text color",
			"description"	=> "Use black color if you use light background",
			"param_name"	=> "text_color",
			"value"			=> array(
				"Black"	=> "black",
				"White"	=> "white"
			),
			"std"			=> "white",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Text size",
			"param_name"	=> "text_size",
			"value"			=> array(
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "Use large text size for large blocks or fullwidth sections",
			"std"			=> "normal",
		),
		array(
			"type"			=> "vc_link",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Button link",
			"description"	=> "Leave empty if you don't need button",
			"param_name"	=> "button_url",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button style",
			"param_name"	=> "button_style",
			"value"			=> array(
				"Bordered"	=> "bordered",
				"Default"	=> "solid",
				"Default invert"	=> "solid-invert",
				"Grey"	=> "grey",
				"Grey invert"	=> "grey-invert",
				"Red"	=> "red",
				"Green"	=> "green"
			),
			"description"	=> "Change button style",
			"std"			=> "solid",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button size",
			"param_name"	=> "button_size",
			"value"			=> array(
				"Small"	=> "small",
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button icon name",
			"description"	=> "If you want to add icon to button you can input Font Awesome icon name here, for example <em>angle-left</em>. <a href='http://fortawesome.github.io/Font-Awesome/icons/' target='_blank'>Check all available icons names</a>.",
			"param_name"	=> "button_icon",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button Text size",
			"param_name"	=> "button_text_size",
			"value"			=> array(
				"Small"	=> "small",
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button Text transform",
			"param_name"	=> "text_tranform",
			"value"			=> array(
				"None"	=> "none",
				"UPPERCASE"	=> "uppercase"
			),
			"description"	=> "",
			"std"			=> "none",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Block link (url)",
			"description"	=> "Add url here if you want to have link for overall block",
			"param_name"	=> "block_url",
			"std"			=> "",
		),
		array(
			"type"			=> "textarea_html",
			"holder"		=> "div",
			"class" 		=> "mgt-promo-block-content-html",
			"admin_label" 	=> false,
			"heading"		=> "Block content",
			"param_name"	=> "content",
			"std"			=> '<strong>Autumn</strong> COLLECTION<p></p><h2>New arrivals</h2><hr><p><em>Shop our new Collection</em></p>',
		)
		
   )

  
   
));