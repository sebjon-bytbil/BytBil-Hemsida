<?php

// VC [button_wp]

vc_map(array(
   "name" 			=> "MGT Button",
   "category" 		=> 'Magnium Content',
   "description"	=> "Button with several styles and link",
   "base" 			=> "mgt_button_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_button",
   
   "params" 	=> array(

		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button style",
			"param_name"	=> "button_style",
			"value"			=> array(
				"Bordered"	=> "bordered",
				"Default"	=> "solid",
				"Default invert"	=> "solid-invert",
				"Grey"	=> "grey",
				"Grey invert"	=> "grey-invert",
				"Red"	=> "red",
				"Green"	=> "green"
			),
			"description"	=> "Change button style",
			"std"			=> "solid",
		),
		array(
			"type"			=> "vc_link",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Button text and link",
			"description"	=> "",
			"param_name"	=> "button_link",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button icon name",
			"description"	=> "If you want to add icon to button you can input Font Awesome icon name here, for example <em>angle-left</em>. <a href='http://fortawesome.github.io/Font-Awesome/icons/' target='_blank'>Check all available icons names</a>.",
			"param_name"	=> "button_icon",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button display",
			"param_name"	=> "button_display",
			"value"			=> array(
				"Inline"	=> "inline",
				"New line"	=> "newline"
			),
			"description"	=> "Use 'New Line' if you want to have only one this button on line, use 'Inline' to have this button inside some content or near other buttons in line.",
			"std"			=> "inline",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button size",
			"param_name"	=> "button_size",
			"value"			=> array(
				"Small"	=> "small",
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Text size",
			"param_name"	=> "text_size",
			"value"			=> array(
				"Small"	=> "small",
				"Normal"	=> "normal",
				"Large"	=> "large"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Text transform",
			"param_name"	=> "text_tranform",
			"value"			=> array(
				"None"	=> "none",
				"UPPERCASE"	=> "uppercase"
			),
			"description"	=> "",
			"std"			=> "none",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Button horizontal align",
			"param_name"	=> "button_align",
			"value"			=> array(
				"Left"	=> "left",
				"Center"	=> "center",
				"Right"	=> "right"
			),
			"description"	=> "",
			"std"			=> "normal",
		),
		
   )

  
   
));