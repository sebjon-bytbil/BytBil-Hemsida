<?php

// VC [header_block_wp]

vc_map(array(
   "name" 			=> "MGT Header Block",
   "category" 		=> 'Magnium Content',
   "description"	=> "Add heading block with header and subheader text",
   "base" 			=> "mgt_header_block_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_header_block",
   
   "params" 	=> array(
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Title",
			"param_name"	=> "title",
			"std"			=> "Header",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Subtitle",
			"param_name"	=> "subtitle",
			"std"			=> "Subheader",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Text align",
			"param_name"	=> "align",
			"value"			=> array(
				"Left"	=> "left",
				"Center"	=> "center",
				"Right"	=> "right"
			),
			"std"			=> "center",
		)
   )
   
));