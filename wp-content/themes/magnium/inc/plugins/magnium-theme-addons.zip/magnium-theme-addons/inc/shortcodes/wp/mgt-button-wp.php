<?php

// Shortcode [button_wp]
function mgt_shortcode_button_wp($atts, $sc_content = null) {
	extract(shortcode_atts(array(
		'button_style' => 'solid',
		'button_link' => '',
		'button_icon' => '',
		'button_display' => 'inline',
		'button_size' => 'normal',
		'button_align' => 'center',
		'text_size' => 'normal',
		'text_tranform' => 'none'
	), $atts));
	
	ob_start();

	$add_class = 'btn mgt-button mgt-style-'.$button_style.' mgt-size-'.$button_size.' mgt-align-'.$button_align.' mgt-display-'.$button_display.' mgt-text-size-'.$text_size.' mgt-text-transform-'.$text_tranform;

	$button_data = vc_build_link($button_link);

	$button_html = '';

	if($button_data['title'] !== '') {
		if($button_icon !== '') {
			$button_icon = '<i class="fa fa-'.$button_icon.'"></i>';
		} else {
			$button_icon = '';
		}

		if($button_data['target'] !== '') {
			$target_html = ' target="'.$button_data['target'].'"';
		} else {
			$target_html = '';
		}

		$button_html = '<a class="'.esc_attr($add_class).'" href="'.esc_attr($button_data['url']).'"'.esc_attr($target_html).'>'.wp_kses_post($button_icon).esc_html($button_data['title']).'</a>';
	}

	echo $button_html;

	$sc_content = ob_get_contents();
	ob_end_clean();
	return $sc_content;
}

add_shortcode("mgt_button_wp", "mgt_shortcode_button_wp");