<?php

// VC [post_list_wp]
$categories = get_terms( 'category', array(
 	'hide_empty' => 0,
));

$category_list = array();
$category_list['Any category'] = '';

foreach ( $categories as $category ) {

	$id = esc_html($category->name);

	$category_list[$id] = esc_html($category->name);
}

vc_map(array(
   "name" 			=> "MGT Posts List",
   "category" 		=> 'Magnium Content',
   "description"	=> "Show posts grid/slider with different layouts",
   "base" 			=> "mgt_post_list_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_post_list",
   
   "params" 	=> array(
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Layout",
			"param_name"	=> "block_size",
			"value"			=> array(
				"4 columns"	=> "small",
				"3 columns"	=> "normal",
				"2 columns"	=> "medium",
				"1 column"	=> "large"
			),
			"std"			=> "small",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Animate block on hover",
			"param_name"	=> "animated",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"description"	=> "Block background will fade to black on mouse hover",
			"std"			=> "1",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Posts display",
			"description"	=> "Masonry layout not available for Slider display",
			"param_name"	=> "use_slider",
			"value"			=> array(
				"Slider"	=> "1",
				"Grid"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Slider autoplay",
			"param_name"	=> "slider_autoplay",
			"dependency"	=> array(
				"element"	=> "use_slider",
				"value"		=> Array("1"),
			),
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Slider show navigation arrows",
			"param_name"	=> "slider_navigation",
			"dependency"	=> array(
				"element"	=> "use_slider",
				"value"		=> Array("1"),
			),
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Slider show navigation pagination",
			"param_name"	=> "slider_pagination",
			"dependency"	=> array(
				"element"	=> "use_slider",
				"value"		=> Array("1"),
			),
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "1",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Category ID's",
			"param_name"	=> "category",
			"description"	=> "Display posts from categories ID's specified in this field, comma separated",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Show Posts from specified category only",
			"param_name"	=> "category_name",
			"value"			=> $category_list,
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Exclude posts by ID's",
			"param_name"	=> "exclude",
			"description"	=> "Excludes one or more posts from the list. This parameter takes a comma-separated list of posts by unique ID, in ascending order.",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Include posts by ID's",
			"param_name"	=> "include",
			"description"	=> "Only include certain posts in the list. This parameter takes a comma-separated list of posts by unique ID, in ascending order.",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Order By",
			"param_name"	=> "orderby",
			"value"			=> array(
				"ID"	=> "id",
				"Title"	=> "title",
				"Date"	=> "date",
				"Random"	=> "rand"
			),
			"std"			=> "date",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Order",
			"param_name"	=> "order",
			"value"			=> array(
				"Desc"	=> "DESC",
				"Asc"	=> "ASC"
			),
			"std"			=> "DESC",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Posts limit",
			"param_name"	=> "posts_per_page",
			"description"	=> "Only this number of posts will be show if specified.",
			"std"			=> "9",
		),

		
   )

  
));