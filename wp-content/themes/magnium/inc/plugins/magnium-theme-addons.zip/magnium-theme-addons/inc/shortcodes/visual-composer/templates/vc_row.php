<?php
$output = $el_class = $bg_image = $bg_color = $bg_image_repeat = $font_color = $padding = $margin_bottom = $row_fullwidth = $row_fullwidth_bg = $row_parallax_bg = $background_image_id = $css = '';
extract(shortcode_atts(array(
    'el_class'        => '',
    'bg_image'        => '',
    'bg_color'        => '',
    'bg_image_repeat' => '',
    'font_color'      => '',
    'padding'         => '',
    'margin_bottom'   => '',
    'row_fullwidth'   => '',
    'row_onepage_id'  => '0',
    'row_parallax_bg' => '',
    'row_fullwidth_bg'   => '',
    'background_image_id' => '',
    'css' => ''
), $atts));

// wp_enqueue_style( 'js_composer_front' );
wp_enqueue_script( 'wpb_composer_front_js' );
// wp_enqueue_style('js_composer_custom_css');

$el_class = $this->getExtraClass($el_class);

if($row_fullwidth_bg == 1) {
    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'vc_row wpb_row '. ( $this->settings('base')==='vc_row_inner' ? 'vc_inner ' : '' ) . get_row_css_class() . $el_class, $this->settings['base'], $atts );
} else {
    $css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'vc_row wpb_row '. ( $this->settings('base')==='vc_row_inner' ? 'vc_inner ' : '' ) . get_row_css_class() . $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );
}
if($row_fullwidth == 1) {
	$css_class .= ' fullwidth-section';
}

// Parallax
$css_class_2 = '';

$parallax_style = '';

if($row_parallax_bg == 1) {

    $css_class_2 = ' parallax';

    $background_image_data = wp_get_attachment_image_src( $background_image_id, 'full' );

    if($background_image_data[0] !== '') {

        $parallax_style = 'background-image: url('.esc_url($background_image_data[0]).');';

    }
}

$style = $this->buildStyle($bg_image, $bg_color, $bg_image_repeat, $font_color, $padding, $margin_bottom);

if($row_fullwidth_bg == 1) {
    $css_bg_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'fullwidth-background '.$css_class_2.vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );

    if($parallax_style !== '') {
        $output .= '<div class="'.$css_bg_class.'" data-style="'.esc_attr($parallax_style).'">';
    } else {
        $output .= '<div class="'.$css_bg_class.'">';
    }
    
}
if($row_onepage_id !== 0) {
    $row_onepage_id = str_replace('#', '', $row_onepage_id);
    $add_id = ' id="'.$row_onepage_id.'"';
} else {
    $add_id = '';
}

if($style !== '') {
    $output .= '<div'.$add_id.' class="'.$css_class.'" data-style="'.esc_attr($style).'">';  
} else {
    $output .= '<div'.$add_id.' class="'.$css_class.'">';
}

$output .= wpb_js_remove_wpautop($content);
$output .= '</div>'.$this->endBlockComment('row');
if($row_fullwidth_bg == 1) {
    $output .= '</div>';
}

echo $output;