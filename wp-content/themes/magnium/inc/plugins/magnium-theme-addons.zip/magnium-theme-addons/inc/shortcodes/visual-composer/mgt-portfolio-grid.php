<?php

// VC [client_reviews_wp]

vc_map(array(
   "name" 			=> "MGT Portfolio Grid",
   "category" 		=> 'Magnium Content',
   "description"	=> "Show portfolio items grid with filter",
   "base" 			=> "mgt_portfolio_grid_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_portfolio_grid",
   
   "params" 	=> array(
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Grid layout",
			"description"	=> "",
			"param_name"	=> "layout",
			"value"			=> array(
				"Equal thumbs"	=> "0",
				"Masonry 1"	=> "1",
				"Masonry 2"	=> "2",
				"Masonry 3"	=> "3"
			),
			"std"			=> "0",
		),
   		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Items per row in grid (columns)",
			"description"	=> "",
			"param_name"	=> "columns",
			"dependency"	=> array(
				"element"	=> "layout",
				"value"		=> Array("0"),
			),
			"value"			=> array(
				"3"	=> "3",
				"4"	=> "4",
				"5"	=> "5"
			),
			"std"			=> "4",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Add spaces between elements in grid",
			"description"	=> "",
			"param_name"	=> "spaces",
			"value"			=> array(
				"No"	=> "0",
				"Yes"	=> "1"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Grid animation effect 1",
			"description"	=> "",
			"param_name"	=> "filter_effect_1",
			"value"			=> array(
				"Fade" => "fade",
				"Scale" => "scale",
				"TranslateX" => "translateX",
				"TranslateY" => "translateY",
				"TranslateZ" => "translateZ",
				"RotateX" => "rotateX",
				"RotateY" => "rotateY",
				"RotateZ" => "rotateZ",
				"Stagger" => "stagger"
			),
			"std"			=> "fade",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Grid animation effect 2",
			"description"	=> "",
			"param_name"	=> "filter_effect_2",
			"value"			=> array(
				"Fade" => "fade",
				"Scale" => "scale",
				"TranslateX" => "translateX",
				"TranslateY" => "translateY",
				"TranslateZ" => "translateZ",
				"RotateX" => "rotateX",
				"RotateY" => "rotateY",
				"RotateZ" => "rotateZ",
				"Stagger" => "stagger"
			),
			"std"			=> "scale",
		),		
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Show project categories ajax filter",
			"param_name"	=> "show_filter",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "1",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Reset filters button text",
			"param_name"	=> "reset_filter_button_text",
			"value"			=> array(
				"All"	=> "All",
				"Recent"	=> "Recent"
			),
			"dependency"	=> array(
				"element"	=> "show_filter",
				"value"		=> Array("1"),
			),
			"std"			=> "All",
			"description"	=> "If you show your portfolio list as part of page with limited items use 'Recent', if you show your portfolio with all items for example on separated Portfolio page use 'All'.",
		),
		array(
			"type"			=> "vc_link",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "View all portfolio items button (link to Portfolio page)",
			"description"	=> "",
			"param_name"	=> "show_viewall_button",
			"std"			=> "",
			"dependency"	=> array(
				"element"	=> "show_filter",
				"value"		=> Array("1"),
			),
			"description"	=> "Leave empty if you don't want to have 'View all' button that open your separated portfolio page. You need to choose to create your portfolio page first and choose its url here.",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Order By",
			"param_name"	=> "orderby",
			"value"			=> array(
				"ID"	=> "id",
				"Title"	=> "title",
				"Date"	=> "date",
				"Random"	=> "rand"
			),
			"std"			=> "date",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Order",
			"param_name"	=> "order",
			"value"			=> array(
				"Desc"	=> "DESC",
				"Asc"	=> "ASC"
			),
			"std"			=> "DESC",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Portfolio grid items limit",
			"param_name"	=> "posts_per_page",
			"description"	=> "Leave empty to show ALL portfolio items on your separated portfolio page. ",
			"std"			=> "",
		),

		
   )

  
));