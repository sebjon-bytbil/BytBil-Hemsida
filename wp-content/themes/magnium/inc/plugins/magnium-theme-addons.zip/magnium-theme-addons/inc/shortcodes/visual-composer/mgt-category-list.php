<?php

// VC [mgt_category_list]

vc_map(array(
   "name" 			=> "MGT Category List",
   "category" 		=> 'Magnium Content',
   "description"	=> "Show product categories list with different layouts",
   "base" 			=> "mgt_category_list_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_category_list",
   
   "params" 	=> array(
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Layout",
			"param_name"	=> "block_size",
			"value"			=> array(
				"4 columns"	=> "small",
				"3 columns"	=> "normal",
				"2 columns"	=> "medium",
				"1 column"	=> "large",
				"Masonry"	=> "masonry"
			),
			"std"			=> "small",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Call to action text",
			"param_name"	=> "call_to_action_text",
			"std"			=> "Discover collection",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Categories display",
			"description"	=> "Masonry layout not available for Slider display",
			"param_name"	=> "use_slider",
			"value"			=> array(
				"Slider"	=> "1",
				"Grid"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Slider autoplay",
			"param_name"	=> "slider_autoplay",
			"dependency"	=> array(
				"element"	=> "use_slider",
				"value"		=> Array("1"),
			),
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Slider show navigation arrows",
			"param_name"	=> "slider_navigation",
			"dependency"	=> array(
				"element"	=> "use_slider",
				"value"		=> Array("1"),
			),
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Slider show navigation pagination",
			"param_name"	=> "slider_pagination",
			"dependency"	=> array(
				"element"	=> "use_slider",
				"value"		=> Array("1"),
			),
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "1",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Show category products count",
			"param_name"	=> "show_post_count",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "0",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Child of (ID)",
			"param_name"	=> "child_of",
			"description"	=> "Display all categories that are descendants (i.e. children & grandchildren) of the category identified by this ID.",
			"std"			=> "0",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Parent ID",
			"param_name"	=> "parent",
			"description"	=> "Display only categories that are direct descendants (i.e. children only) of the category identified by this ID. Use 0 to show root categories only, leave empty to show all categories.",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Hide empty categories",
			"param_name"	=> "hide_empty",
			"value"			=> array(
				"Yes"	=> "1",
				"No"	=> "0"
			),
			"std"			=> "1",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Exclude categories by ID's",
			"param_name"	=> "exclude",
			"description"	=> "Excludes one or more categories from the list. This parameter takes a comma-separated list of categories by unique ID, in ascending order.",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Include categories by ID's",
			"param_name"	=> "include",
			"description"	=> "Only include certain categories in the list. This parameter takes a comma-separated list of categories by unique ID, in ascending order.",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Order By",
			"param_name"	=> "orderby",
			"value"			=> array(
				"ID"	=> "id",
				"Name"	=> "name",
				"Slug"	=> "slug",
				"Count"	=> "count"
			),
			"std"			=> "name",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Order",
			"param_name"	=> "order",
			"value"			=> array(
				"Desc"	=> "desc",
				"Asc"	=> "asc"
			),
			"std"			=> "asc",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Categories limit",
			"param_name"	=> "number",
			"description"	=> "Only this number of categories will be show if specified.",
			"std"			=> "",
		),

		
   )

  
));