<?php

// Shortcode [mmm_menu_wp]
function mgt_shortcode_mmm_menu_wp($atts, $content = null) {

	global $theme_options;

	extract(shortcode_atts(array(
		'menu_location' => 'left',
		'menu_type' => 'horizontal'
	), $atts));
	ob_start();

	if(isset($theme_options['megamenu_enable']) && $theme_options['megamenu_enable']) {
        $add_class = " mgt-mega-menu";
	}

	$add_class .= ' '.'mgt-menu-'.$menu_type;

	?>
    <div class="navbar navbar-default clearfix<?php echo esc_attr($add_class);?>">
      <div class="navbar-inner">
         
         
          <div class="navbar-toggle" data-toggle="collapse" data-target=".collapse">
            <?php _e( 'Menu', 'magnium' ); ?>
          </div>

          <?php
          if(isset($theme_options['megamenu_enable']) && $theme_options['megamenu_enable']) {
            wp_nav_menu(array(
              'theme_location'  => 'primary',
              'container_class' => 'navbar-collapse collapse',
              'menu_class'      => 'nav',
              'theme_location' => $menu_location,
              'walker'          => new rc_scm_walker
              )); 
          } else {
             wp_nav_menu(array(
              'theme_location'  => 'primary',
              'container_class' => 'navbar-collapse collapse',
              'menu_class'      => 'nav',
              'theme_location' => $menu_location,
              'walker'          => new description_walker
              ));  
          }
          
          ?>
     
      </div>
    </div>

	<?php

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("mgt_mmm_menu_wp", "mgt_shortcode_mmm_menu_wp");