<?php

// VC [icon_box_wp]

vc_map(array(
   "name" 			=> "MGT Icon Box",
   "category" 		=> 'Magnium Content',
   "description"	=> "Block with title, subtitle, content and icon image",
   "base" 			=> "mgt_icon_box_wp",
   "class" 			=> "",
   "icon" 			=> "vc_mgt_icon_box",
   
   "params" 	=> array(
   		array(
			"type"			=> "attach_image",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> false,
			"heading"		=> "Icon image",
			"description"	=> "Image will be scaled to 35x35px",
			"param_name"	=> "icon_image_id",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Subtitle",
			"param_name"	=> "subtitle",
			"std"			=> "",
		),
		array(
			"type"			=> "textfield",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Title",
			"param_name"	=> "title",
			"std"			=> "",
		),
		array(
			"type"			=> "dropdown",
			"holder"		=> "div",
			"class" 		=> "hide_in_vc_editor",
			"admin_label" 	=> true,
			"heading"		=> "Title/Subtitle position",
			"param_name"	=> "title_position",
			"value"			=> array(
				"Below icon (Top)"	=> "top",
				"In content (Right)"	=> "right",
				"Below icon with text (align all centered)"	=> "centered"
			),
			"description"	=> "Change icon box layout",
			"std"			=> "top",
		),
		array(
			"type"			=> "textarea_html",
			"holder"		=> "div",
			"class" 		=> "mgt-promo-block-content-html",
			"admin_label" 	=> false,
			"heading"		=> "Box content",
			"param_name"	=> "content",
			"std"			=> 'Sample text',
		)
		
   )

  
   
));