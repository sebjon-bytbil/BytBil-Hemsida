<?php

// Shortcode [featured_products_wp]

function mgt_shortcode_featured_products_wp($atts, $content = null) {
	extract(shortcode_atts(array(
		'use_slider' => 0,
		'slider_autoplay' => 0,
		'slider_navigation' => 0,
		'slider_pagination' => 1,
		'products_per_row' => 4,
		'per_page'  => '10',
        'orderby' => 'date',
        'order' => 'desc',
        'columns' => '4'
	), $atts));
	ob_start();

	$style = '';

	if($use_slider == 1) {

		$style = ' style="display: none;"';

		if($slider_autoplay == 1) {
			$slider_autoplay = 'true';
		} else {
			$slider_autoplay = 'false';
		}
		if($slider_navigation == 1) {
			$slider_navigation = 'true';
		} else {
			$slider_navigation = 'false';
		}
		if($slider_pagination == 1) {
			$slider_pagination = 'true';
		} else {
			$slider_pagination = 'false';
		}

		echo '<div class="mgt-products-list-wrapper">';
	}

	$rand_id = rand(1000,100000);

	echo '<div id="mgt-products-list-'.intval($rand_id).'" class="mgt-products-list mgt-featured-products columns-'.esc_attr($products_per_row).' wpb_content_element"'.$style.'>';

	echo do_shortcode('[featured_products per_page="'.esc_attr($per_page).'" columns="'.esc_attr($columns).'" orderby="'.esc_attr($orderby).'" order="'.esc_attr($order).'"]');

	echo '</div>';

	if($use_slider == 1) {
		echo '</div>';

		echo '<script>(function($){
	    $(document).ready(function() {

		    $("#mgt-products-list-'.intval($rand_id).' ul.products").owlCarousel({
	            items: '.esc_js($products_per_row).',
	            itemsDesktop: [1024,3],
	            itemsTablet: [770,2],
	            itemsMobile : [480,1],
	            autoPlay: '.esc_js($slider_autoplay).',
	            navigation: '.esc_js($slider_navigation).',
	            navigationText : false,
	            pagination: '.esc_js($slider_pagination).',
	            afterInit : function(elem){
	                $("#mgt-products-list-'.intval($rand_id).'").css("display", "block");
	            }
		    });
	    });})(jQuery);</script>';
	}
	
	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("mgt_featured_products_wp", "mgt_shortcode_featured_products_wp");