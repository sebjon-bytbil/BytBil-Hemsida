<?php

// Shortcode [promo_block_wp]
function mgt_shortcode_promo_block_wp($atts, $sc_content = null) {
	extract(shortcode_atts(array(
		'background_image_id' => '',
		'background_color' => '',
		'background_repeat' => 'no-repeat',
		'parallax' => 0,
		'block_width' => '',
		'block_height' => '',
		'animated' => 1,
		'darken' => 0,
		'coverimage' => 0,
		'text_size' => 'normal',
		'is_category_usage' => 0,
		'text_color' => 'white',
		'button_url' => '',
		'button_style' => 'solid',
		'button_icon' => '',
		'button_size' => 'normal',
		'button_text_size' => 'normal',
		'text_tranform' => 'none',
		'block_url'	=> ''
	), $atts));
	
	ob_start();

	$style = '';

	if($is_category_usage == 1) {
		$background_image_size = 'mgt-category-image-large';
	} else {
		$background_image_size = 'full';
	}
	if(($is_category_usage == 1)&&($parallax == 1)) {
		$background_image_size = 'full';
	}

	$background_image_data = wp_get_attachment_image_src( $background_image_id, $background_image_size );

	$no_image_class = '';

	if($background_image_data[0] == '') {
		if($background_color !== '') {
			$style = 'background-color: '.$background_color.';';
		}

		if($is_category_usage > 0) {
			$no_image_class = ' without-image';
		}

		if($block_width == '') {
			$block_width = '100%';
		}

		if($block_height == '') {
			$block_height = 'auto';
		}
	} else {

		if($background_color !== '') {
			$style .= 'background-color: '.$background_color.';';
		}

		$style .= 'background-image: url('.$background_image_data[0].');';

		$style .= 'background-repeat: '.$background_repeat.';';

		if($block_width == '') {
			$block_width = $background_image_data[1].'px';
		}

		if($block_height == '') {
			$block_height = $background_image_data[2].'px';
		}
	}

	$add_class = '';

	$add_class .= $no_image_class;

	if($animated == 1) {
		$add_class .= ' animated';
	}
	if($parallax == 1) {
		$add_class .= ' parallax';
	}
	if($text_color == 'white') {
		$add_class .= ' white-text';
	} else {
		$add_class .= ' black-text';
	}

	if($coverimage == 1) {
		$add_class .= ' cover-image';
	}

	$add_class .= ' text-size-'.$text_size;

	$add_class .= ' '.$darken;

	$style .= 'width: '.$block_width.'; height: '.$block_height.';';

	$button_data = vc_build_link($button_url);

	$button_html = '';

	if($button_data['title'] !== '') {

		$button_html = do_shortcode('[mgt_button_wp button_style="'.$button_style.'" button_link="'.$button_url.'" button_icon="'.$button_icon.'" button_display="inline" button_size="'.$button_size.'" text_size="'.$button_text_size.'" text_tranform="'.$text_tranform.'" button_align="center"]');

	}

	if($is_category_usage == 0) {
		$sc_content = str_replace('<p>', '', $sc_content);
		$sc_content = str_replace('</p>', '', $sc_content);
	}

	if(trim($block_url !== '')) {
		echo '<a href="'.esc_url($block_url).'">';
	}

	echo '<div class="mgt-promo-block'.esc_attr($add_class).' wpb_content_element" data-style="'.esc_attr($style).'"><div class="mgt-promo-block-content">'.wp_kses_post($sc_content).''.$button_html.'</div></div>';

	if(trim($block_url !== '')) {
		echo '</a>';
	}

	$sc_content = ob_get_contents();
	ob_end_clean();
	return $sc_content;
}

add_shortcode("mgt_promo_block_wp", "mgt_shortcode_promo_block_wp");