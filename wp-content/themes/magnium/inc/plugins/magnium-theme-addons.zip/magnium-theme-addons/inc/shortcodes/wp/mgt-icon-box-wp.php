<?php

// Shortcode [icon_box_wp]
function mgt_shortcode_icon_box_wp($atts, $sc_content = null) {
	extract(shortcode_atts(array(
		'icon_image_id' => '',
		'title' => 'Header',
		'subtitle' => '',
		'title_position' => 'top'
	), $atts));
	
	ob_start();

	$icon_image_data = wp_get_attachment_image_src( $icon_image_id, 'mgt-image-square-small' );

	if($icon_image_data !== false) {
		$icon_image_html = '<img src="'.esc_url($icon_image_data[0]).'" alt="'.esc_attr($title).'"/>';
	} else {
		$icon_image_html = '';
	}

	$add_class = ' mgt-icon-box-'.$title_position;

	if($subtitle !== '') {
		$subtitle_html = '<h6>'.esc_html($subtitle).'</h6>';
	}

	if($title_position == 'right' || $title_position == 'centered') {
		echo '<div class="mgt-icon-box wpb_content_element'.esc_attr($add_class).'"><div class="mgt-icon-box-icon">'.$icon_image_html.'</div><div class="mgt-icon-box-content">'.$subtitle_html.'<h5>'.esc_html($title).'</h5>'.wp_kses_post($sc_content).'</div><div class="clearfix"></div></div>';
	} else {
		echo '<div class="mgt-icon-box wpb_content_element">'.$subtitle_html.'<h5>'.esc_html($title).'</h5><div class="mgt-icon-box-icon">'.$icon_image_html.'</div><div class="mgt-icon-box-content">'.wp_kses_post($sc_content).'</div><div class="clearfix"></div></div>';
	}
	
	$sc_content = ob_get_contents();
	ob_end_clean();
	return $sc_content;
}

add_shortcode("mgt_icon_box_wp", "mgt_shortcode_icon_box_wp");