<?php

// Shortcode [category_list_wp]
function mgt_shortcode_category_list_wp($atts, $content = null) {
	extract(shortcode_atts(array(
		'block_size' => 'masonry', /* small, normal, medium, large, masonry */
		'call_to_action_text' => 'Discover collection',
		'use_slider' => 0,
		'slider_autoplay' => 0,
		'slider_navigation' => 0,
		'slider_pagination' => 1,
		'show_post_count' => 0,
		'child_of' => 0,
		'parent' => '', /* Parent ID */
        'hide_empty' => 1,
        'exclude' => '',
        'include' => '',
        'orderby' => 'name',
        'order' => 'ASC',
        'number' => ''
	), $atts));
	ob_start();

	$args = array(
	  'child_of' => $child_of,
	  'parent' => $parent,
	  'hide_empty' => $hide_empty,
	  'exclude' => $exclude,
	  'include' => $include,
	  'orderby' => $orderby,
	  'order' => $order,
	  'number' => $number,
	  'taxonomy' => 'product_cat'
	);

	$categories = get_categories($args);

	if(count($categories) == 1) {
		$single_category = ' mgt-single-category';
	} else {
		$single_category = '';
	}

	$rand_id = rand(1000,100000);

	if(($use_slider == 1)&&($block_size == 'masonry')) {
  		$block_size = 'small';
  	}

  	if($block_size == 'small') {
  		$image_size = 'mgt-category-image-small';
  		$slider_items = 4;
  	}
  	if($block_size == 'normal') {
  		$image_size = 'mgt-category-image-normal';
  		$slider_items = 3;
  	}
  	if($block_size == 'medium') {
  		$image_size = 'mgt-category-image-medium';
  		$slider_items = 2;
  	}
  	if($block_size == 'large') {
  		$image_size = 'mgt-category-image-large';
  		$slider_items = 1;
  	}
  	if($block_size == 'masonry') {
  		//$image_size = 'mgt-category-image-large';
  		$image_size = 'full';
  	}

  	$style = '';

	if($use_slider == 1) {

		$style = ' style="display: none;"';

		if($slider_autoplay == 1) {
			$slider_autoplay = 'true';
		} else {
			$slider_autoplay = 'false';
		}
		if($slider_navigation == 1) {
			$slider_navigation = 'true';
		} else {
			$slider_navigation = 'false';
		}
		if($slider_pagination == 1) {
			$slider_pagination = 'true';
		} else {
			$slider_pagination = 'false';
		}

		echo '<div class="mgt-categories-list-wrapper">';
	}

	echo '<div id="mgt-categories-list-'.intval($rand_id).'" class="mgt-categories-list'.esc_attr($single_category).' wpb_content_element"'.$style.'>';

	foreach($categories as $category) { 
	  	echo '<div class="mgt-category '.$block_size.'-blocks">';

	  	$thumbnail_id = get_woocommerce_term_meta( $category->term_id, 'thumbnail_id', true );

	    $image = wp_get_attachment_image_src( $thumbnail_id, $image_size );

	    if($image !== false) {
	    	$image_bg = 'background-image: url('.$image[0].');';
	    }
	    else {
	    	$image_bg = '';
	    }
	    
	    if($show_post_count == 1) {
	  		$category_name = $category->name.' ('.$category->count.')';
	  	} else {
	  		$category_name = $category->name;
	  	}

	  	echo '<a href="' . get_term_link($category->slug, 'product_cat') . '"' . '><div class="mgt-category-image" data-style="'.esc_attr($image_bg).'"><div class="mgt-category-details"><div class="arrow"></div>'.esc_html($category_name).'<div class="line"></div><div class="mgt-category-action-text">'.esc_html($call_to_action_text).'</div></div></div></a>';

	    echo '</div>';
	} 

	echo '<div class="clearfix"></div>';
	echo '</div>';

	if($use_slider == 1) {
		echo '</div>';
	}

	if($use_slider == 1) {
		echo '<script>(function($){
	    $(document).ready(function() {

		    $("#mgt-categories-list-'.intval($rand_id).'").owlCarousel({
	            items: '.esc_js($slider_items).',
	            itemsDesktop: [1024,3],
	            itemsTablet: [770,2],
	            itemsMobile : [480,1],
	            autoPlay: '.esc_js($slider_autoplay).',
	            navigation: '.esc_js($slider_navigation).',
	            navigationText : false,
	            pagination: '.esc_js($slider_pagination).',
	            afterInit : function(elem){
	                $(this).css("display", "block");
	            }
		    });
	    });})(jQuery);</script>';
	}

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("mgt_category_list_wp", "mgt_shortcode_category_list_wp");