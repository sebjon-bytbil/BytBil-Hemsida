<?php

// Shortcode [header_block_wp]
function mgt_shortcode_header_block_wp($atts, $sc_content = null) {
	extract(shortcode_atts(array(
		'title' => 'Header',
		'subtitle' => 'Subheader',
		'align' => 'center'
	), $atts));
	
	ob_start();

	if($subtitle !== '') {
		$subtitle = '<p>'.$subtitle.'</p>';
	}

	echo '<div class="mgt-header-block text-'.esc_attr($align).' wpb_content_element"><h5>'.esc_html($title).'</h5>'.wp_kses_post($subtitle).'</div>';

	$sc_content = ob_get_contents();
	ob_end_clean();
	return $sc_content;
}

add_shortcode("mgt_header_block_wp", "mgt_shortcode_header_block_wp");