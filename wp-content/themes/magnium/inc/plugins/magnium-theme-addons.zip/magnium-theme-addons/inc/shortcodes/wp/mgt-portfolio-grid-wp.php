<?php

// Shortcode [portfolio_grid_wp]
function mgt_shortcode_portfolio_grid_wp($atts, $content = null) {

	global $wp_query, $post;

	extract(shortcode_atts(array(
		'columns' => 0,
		'layout' => 0,
        'spaces' => 0,
		'show_filter' => 1,
		'filter_effect_1' => 'fade',
		'filter_effect_2' => 'scale',
		'reset_filter_button_text' => 'All',
		'show_viewall_button' => '',
        'orderby' => 'date',
        'order' => 'ASC',
        'posts_per_page' => ''
	), $atts));
	ob_start();

	if((trim($posts_per_page) == '')||($posts_per_page == 0)) {
		$posts_per_page = 10000;
	}

	$all_terms = get_terms( 'mgt_portfolio_filter');

	$show_viewall_button_data = vc_build_link($show_viewall_button);

	if($layout == 1) {
		$spaces = 0;
	}
	
	if($spaces == 1) {
		$add_class = ' portfolio-with-spaces ';
	} else {
		$add_class = '';
	}

	?>
	<?php if((count($all_terms) > 1) && ($show_filter == 1)): ?>
	<div class="row portfolio-filter">
		<div class="col-md-12 text-center">
		<a class="filter" data-filter="all"><?php echo $reset_filter_button_text; ?></a>
		<?php 
		foreach ( $all_terms as $term ) {
		  echo '<a class="filter" data-filter=".'.$term->slug.'">'.$term->name.'</a> ';
		}
		?> 
		<?php if($show_viewall_button_data['title'] !== ''): ?>
		  <?php echo '<a class="filter view-all" href="'.$show_viewall_button_data['url'].'" target="'.$show_viewall_button_data['target'].'">'.$show_viewall_button_data['title'].'</a>'; ?>
		<?php endif; ?>
		</div>
	</div>
	<?php endif; ?>

	<div class="portfolio-list portfolio-columns-<?php echo $columns; ?> portfolio-grid-layout-<?php echo $layout;?> <?php echo $add_class; ?>clearfix" id="portfolio-list">

	<?php

	$temp = $wp_query;
	$wp_query = null;

	$data_item = 0;

	$wp_query = new WP_Query(array(
		'post_type' => 'mgt_portfolio',
		'posts_per_page' => $posts_per_page,
		'orderby'    => $orderby,
			'order' => $order
	));

	while ($wp_query->have_posts()) : $wp_query->the_post();
	  
	  $data_item++;
	  
	  $portfolio_small = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'mgt-portfolio-thumb-square' );

	  $portfolio_brand = get_post_meta( $post->ID, '_portfolio_brand_value', true );
	  $portfolio_brand_url = get_post_meta( $post->ID, '_portfolio_brand_url_value', true );
	  $portfolio_url = get_post_meta( $post->ID, '_portfolio_url_value', true );

	  $terms = get_the_terms( $post->ID , 'mgt_portfolio_filter' );

	  $terms_count = count($terms);

	  $terms_counter = 0;

	  $terms_slug = '';

	  $categories_html = '';

	  foreach ( $terms ? $terms: array() as $term ) {

	    if($terms_counter  < $terms_count - 1) {
	      $categories_html.= $term->name.' / ';
	    }
	    else
	    {
	      $categories_html .= $term->name;
	    }
	    
	    $terms_slug .= ' '.$term->slug;

	    $terms_counter++;
	  }

	  $style = 'background-image: url('.$portfolio_small[0].');';

	?>
	<div class="portfolio-item-block mix<?php echo esc_attr($terms_slug); ?>" data-item="<?php echo esc_attr($data_item); ?>" data-name="<?php the_title(); ?>">
	<div class="portfolio-item-block-inside">
	  <a href="<?php echo get_permalink( $post->ID );?>">
	    <div class="portfolio-item-image" data-style="<?php echo esc_attr($style); ?>"></div>
	    <div class="portfolio-item-bg"></div>
	    <div class="info">
	      <span class="sub-title"><?php echo esc_html($categories_html); ?></span>
	      <h4 class="title"><?php the_title(); ?></h4>
	    </div>
	  </a>
	</div>
	</div>
	<?php 
	if($data_item == 3){
	  $data_item = 0;
	}

	endwhile; // end of the loop. 

	wp_reset_query();

	?>
	         
	<?php $wp_query = null; $wp_query = $temp;?>

	</div>


<?php
    echo '<script>(function($){
	    $(document).ready(function() {

		    $("#portfolio-list").mixItUp({effects:["'.esc_js($filter_effect_1).'","'.esc_js($filter_effect_2).'"],easing:"snap"});

	    });})(jQuery);</script>';

	$content = ob_get_contents();
	ob_end_clean();
	return $content;
}

add_shortcode("mgt_portfolio_grid_wp", "mgt_shortcode_portfolio_grid_wp");
