<?php
/*
Plugin Name: Magnium Theme Addons
Plugin URI: http://magniumthemes.com/
Description: Custom Post Types and Shortcodes for Magnium WordPress theme
Author: dedalx
Version: 1.0.1
Author URI: http://magniumthemes.com/
Text Domain: magnium-cpt
License: General Public License
*/

// Define current version constant
define( 'magnium_CPT_VERSION', '2.0' );

// Define current WordPress version constant
define( 'magnium_CPT_WP_VERSION', get_bloginfo( 'version' ) );

//load translated strings
add_action( 'init', 'magnium_cpt_load_textdomain' );

//load init
add_action( 'init', 'magnium_cpt_init' );

//process custom taxonomies
add_action( 'init', 'magnium_cpt_create_custom_taxonomies', 0 );

//process custom post types
add_action( 'init', 'magnium_cpt_create_custom_post_types', 0 );

//process custom meta boxes
add_action( 'init', 'magnium_cpt_create_metaboxes', 0 );

//flush rewrite rules on deactivation
register_deactivation_hook( __FILE__, 'magnium_cpt_deactivation' );

function magnium_cpt_deactivation() {
	// Clear the permalinks to remove our post type's rules
	flush_rewrite_rules();
}

function magnium_cpt_load_textdomain() {
	load_plugin_textdomain( 'magnium_cpt_plugin', false, basename( dirname( __FILE__ ) ) . '/languages' );
}

function magnium_cpt_init() {
	add_image_size( 'mgt-category-image-small', 270, 315, true);
	add_image_size( 'mgt-category-image-normal', 370, 315, true);
	add_image_size( 'mgt-category-image-medium', 570, 315, true);
	add_image_size( 'mgt-category-image-large', 1170, 315, true);
	add_image_size( 'mgt-post-image-small', 270, 230, true);
	add_image_size( 'mgt-post-image-normal', 370, 230, true);
	add_image_size( 'mgt-post-image-medium', 570, 230, true);
	add_image_size( 'mgt-post-image-large', 1170, 230, true);
	add_image_size( 'mgt-portfolio-thumb-square', 1024, 1024, true);
	add_image_size( 'mgt-portfolio-small', 700, 700, true);
    add_image_size( 'mgt-portfolio-large', 1170, 799, true);
    add_image_size( 'mgt-portfolio-nav', 100, 100, true);
}

function magnium_cpt_create_custom_post_types() {
	
	function magnium_posts_types() {

		register_post_type( 'mgt_clients_reviews',
		array(
		    'labels' => array(
		    'name' => __( 'Clients reviews', 'magnium-cpt' ),
		    'singular_name' => __( 'Clients reviews', 'magnium-cpt' ),
		    'has_archive' => true,
		    'add_new' => __( 'Add review', 'magnium-cpt' ),
		    'not_found' => __( 'Not found', 'magnium-cpt' ),
		    'not_found_in_trash' => __( 'No clients reviews found in trash', 'magnium-cpt' ),
		    'add_new_item' => __( 'Add review', 'magnium-cpt' ),
		    'all_items' => __( 'All client reviews', 'magnium-cpt' ),
		    ),
		    'public' => true,
		    'has_archive' => true,
		    'supports' => array(
		        'title',
		        'thumbnail',
		        'editor',
		        'comments'
		    ),
		    'menu_icon' => plugin_dir_url('magnium-theme-addons').'magnium-theme-addons/img/admin/icon-team.png'
		));

		register_post_type( 'mgt_portfolio',
		array(
		    'labels' => array(
		    'name' => __( 'Portfolio items', 'magnium-cpt' ),
		    'singular_name' => __( 'Portfolio items', 'magnium-cpt' ),
		    'has_archive' => true,
		    'add_new' => __( 'Add New item', 'magnium-cpt' ),
		    'not_found' => __( 'Not found', 'magnium-cpt' ),
		    'not_found_in_trash' => __( 'No Portfolio items found in trash', 'magnium-cpt' ),
		    'add_new_item' => __( 'Add New item', 'magnium-cpt' ),
		    'all_items' => __( 'All Portfolio items', 'magnium-cpt' ),
		    ),
		    'public' => true,
		    'has_archive' => true,
		    'rewrite' => array(
		    	'slug' => 'portfolio-item'
		    ),
		    'supports' => array(
		        'title',
		        'thumbnail',
		        'editor',
		        'comments'
		    ),
		    'menu_icon' => plugin_dir_url('magnium-theme-addons').'magnium-theme-addons/img/admin/icon-portfolio.png'
		));
	}

	add_action( 'init', 'magnium_posts_types' );	
}

function magnium_cpt_create_custom_taxonomies() {
	function magnium_register_portfolio_taxonomy() {
	    register_taxonomy("mgt_portfolio_filter", array("mgt_portfolio"), array("hierarchical" => true, "label" => "Project category", "singular_label" => "Project Category", "rewrite" => true, "show_admin_column" => true));
	}
	add_action( 'init', 'magnium_register_portfolio_taxonomy');
}

function magnium_cpt_create_metaboxes() {

	/**
	* Custom metabox for Our Team custom post type
	**/

	function reviews_image_box() {

	    remove_meta_box('postimagediv', 'mgt_clients_reviews', 'side');
	    
	    add_meta_box('postimagediv', __('Client photo/logo', 'magnium-cpt'), 'post_thumbnail_meta_box', 'mgt_clients_reviews', 'normal', 'high');

	}

	add_action('do_meta_boxes', 'reviews_image_box');

	/**
	* Custom metabox for Portfolio custom post type
	**/

	function portfolio_image_box() {

	    remove_meta_box('postimagediv', 'mgt_portfolio', 'side');
	    
	    add_meta_box('postimagediv', __('Portfolio grid item image', 'magnium-cpt'), 'post_thumbnail_meta_box', 'mgt_portfolio', 'normal', 'high');

	}
	add_action('do_meta_boxes', 'portfolio_image_box');

	function portfolio_settings_box() {

	    $screens = array( 'mgt_portfolio' );

	    foreach ( $screens as $screen ) {

	        add_meta_box(
	            'portfolio_settings_box',
	            __( 'Portfolio item page details and settings', 'magnium-cpt' ),
	            'portfolio_settings_inner_box',
	            $screen,
	            'normal'
	        );
	    }
	}
	add_action( 'add_meta_boxes', 'portfolio_settings_box' );

	function portfolio_settings_inner_box( $post ) {

		// Add an nonce field so we can check for it later.
		wp_nonce_field( 'portfolio_settings_inner_box', 'portfolio_settings_inner_box_nonce' );

		/*
		* Use get_post_meta() to retrieve an existing value
		* from the database and use the value for the form.
		*/

		$value_page_fullwidth = get_post_meta( $post->ID, '_page_fullwidth_value', true );

		$checked = '';
		if( $value_page_fullwidth == true ) { 
			$checked = 'checked = "checked"';
		}

		echo '<p><input type="checkbox" id="page_fullwidth" name="page_fullwidth" '.$checked.' /> <label for="page_fullwidth">'.__( "Allow fullwidth elements on this page (rows with 'Fullwidth row' option checked will be fullwidth, assigned page sidebar will disabled)", 'magnium-cpt' ).'</label></p>';

		$value_portfolio_hide_details = get_post_meta( $post->ID, '_portfolio_hide_details_value', true );

		$checked = '';
		if( $value_portfolio_hide_details == true ) { 
			$checked = 'checked = "checked"';
		}
		echo '<p><input type="checkbox" id="portfolio_hide_details" name="portfolio_hide_details" '.$checked.' /> <label for="portfolio_hide_details">'.__( "Hide portfolio details (Date, Client, Project url, Category)", 'magnium-cpt' ).'</label></p>';

		$value_portfolio_url = get_post_meta( $post->ID, '_portfolio_url_value', true );
		
		echo '<p><label for="portfolio_url" style="width: 100px; display: inline-block;">';
		_e( "Project url: ", 'magnium-cpt' );
		echo '</label> ';
		echo '<input type="text" id="portfolio_url" name="portfolio_url" value="' . esc_attr( $value_portfolio_url ) . '" size="30" /></p>';

		$value_portfolio_brand = get_post_meta( $post->ID, '_portfolio_brand_value', true );
		
		echo '<p><label for="portfolio_brand" style="width: 100px; display: inline-block;">';
		_e( "Brand title: ", 'magnium-cpt' );
		echo '</label> ';
		echo '<input type="text" id="portfolio_brand" name="portfolio_brand" value="' . esc_attr( $value_portfolio_brand ) . '" size="30" /></p>';

		$value_portfolio_brand_url = get_post_meta( $post->ID, '_portfolio_brand_url_value', true );
		
		echo '<p><label for="portfolio_brand_url" style="width: 100px; display: inline-block;">';
		_e( "Brand url: ", 'magnium-cpt' );
		echo '</label> ';
		echo '<input type="text" id="portfolio_brand_url" name="portfolio_brand_url" value="' . esc_attr( $value_portfolio_brand_url ) . '" size="30" /></p>';

		$value_portfolio_display_type = get_post_meta( $post->ID, '_portfolio_display_type_value', true );
		
		echo '<p><label for="portfolio_display_type" style="width: 100px; display: inline-block;">';
		_e( "Layout: ", 'magnium-cpt' );
		echo '</label> ';
		echo '<label><input type="radio" name="portfolio_display_type" value="0"'; 
		if($value_portfolio_display_type == 0) { echo 'checked'; }
		echo ' >';
		_e( "Normal image size, description at the right", 'magnium-cpt' ).'</label>';
		echo ' &nbsp;<label><input type="radio" name="portfolio_display_type" value="1"';
		if($value_portfolio_display_type == 1) { echo 'checked'; }
		echo '>'; 
		_e( "Full width image size, description at the bottom", 'magnium-cpt' ).'</label>';

		$value_portfolio_disableslider = get_post_meta( $post->ID, '_portfolio_disableslider_value', true );

		$checked = '';
		if( $value_portfolio_disableslider == true ) { 
			$checked = 'checked = "checked"';
		}
		echo '<p><input type="checkbox" id="portfolio_disableslider" name="portfolio_disableslider" '.$checked.' /> <label for="portfolio_disableslider">'.__( "Disable slider for this item images (show images in column)", 'magnium-cpt' ).'</label></p>';

		$value_portfolio_fullwidthslider = get_post_meta( $post->ID, '_portfolio_fullwidthslider_value', true );

		$checked = '';
		if( $value_portfolio_fullwidthslider == true ) { 
			$checked = 'checked = "checked"';
		}
		echo '<p><input type="checkbox" id="portfolio_fullwidthslider" name="portfolio_fullwidthslider" '.$checked.' /> <label for="portfolio_fullwidthslider">'.__( "Show item images or slider fullwidth (liquid)", 'magnium-cpt' ).'</label></p>';

		$value_portfolio_original_image_sizes = get_post_meta( $post->ID, '_portfolio_original_image_sizes_value', true );

		$checked = '';
		if( $value_portfolio_original_image_sizes == true ) { 
			$checked = 'checked = "checked"';
		}
		echo '<p><input type="checkbox" id="portfolio_original_image_sizes" name="portfolio_original_image_sizes" '.$checked.' /> <label for="portfolio_original_image_sizes">'.__( "Use original images sizes for all item images (don't crop images)", 'magnium-cpt' ).'</label></p>';


		$value_portfolio_hide_1st_image_from_slider = get_post_meta( $post->ID, '_portfolio_hide_1st_image_from_slider_value', true );

		$checked = '';
		if( $value_portfolio_hide_1st_image_from_slider == true ) { 
			$checked = 'checked = "checked"';
		}
		echo '<p><input type="checkbox" id="portfolio_hide_1st_image_from_slider" name="portfolio_hide_1st_image_from_slider" '.$checked.' /> <label for="portfolio_hide_1st_image_from_slider">'.__( "Don't show 'Portfolio grid item image' on item page", 'magnium-cpt' ).'</label></p>';

		$value_portfolio_socialshare_disable = get_post_meta( $post->ID, '_portfolio_socialshare_disable_value', true );

		$checked = '';
		if( $value_portfolio_socialshare_disable == true ) { 
			$checked = 'checked = "checked"';
		}

		echo '<p><input type="checkbox" id="portfolio_socialshare_disable" name="portfolio_socialshare_disable" '.$checked.' /> <label for="portfolio_socialshare_disable">'.__( "Disable social share counters and buttons on this item page", 'magnium-cpt' ).'</label></p>';

		$value_portfolio_titleposition = get_post_meta( $post->ID, '_portfolio_titleposition_value', true );

		$selected_1 = '';
		$selected_2 = '';
		$selected_3 = '';

		if($value_portfolio_titleposition == "default") {
			$selected_1 = ' selected';
		}
		if($value_portfolio_titleposition == "description") {
			$selected_2 = ' selected';
		}
		if($value_portfolio_titleposition == "disable") {
			$selected_3 = ' selected';
		}

		echo '<p><label for="portfolio_titleposition" style="display: inline-block; width: 150px;">'.__( "Title position: ", 'magnium-cpt' ).'</label>';
		echo '<select name="portfolio_titleposition" id="portfolio_titleposition">
		    <option value="default"'.$selected_1.'>'.__( "Page title", 'magnium-cpt' ).'</option>
		    <option value="description"'.$selected_2.'>'.__( "Before description and details", 'magnium-cpt' ).'</option>
		    <option value="disable"'.$selected_3.'>'.__( "Disable title", 'magnium-cpt' ).'</option>
		</select></p>';


		$value_portfolio_sidebarposition = get_post_meta( $post->ID, '_portfolio_sidebarposition_value', true );

		$selected_1 = '';
		$selected_2 = '';
		$selected_3 = '';
		$selected_4 = '';

		if($value_portfolio_sidebarposition == 0) {
			$selected_1 = ' selected';
		}
		if($value_portfolio_sidebarposition == "left") {
			$selected_2 = ' selected';
		}
		if($value_portfolio_sidebarposition == "right") {
			$selected_3 = ' selected';
		}
		if($value_portfolio_sidebarposition == "disable") {
			$selected_4 = ' selected';
		}

		echo '<p><label for="portfolio_sidebarposition" style="display: inline-block; width: 150px;">'.__( "Sidebar position: ", 'magnium-cpt' ).'</label>';
		echo '<select name="portfolio_sidebarposition" id="portfolio_sidebarposition">
		    <option value="0"'.$selected_1.'>'.__( "Use theme control panel settings", 'magnium-cpt' ).'</option>
		    <option value="left"'.$selected_2.'>'.__( "Left", 'magnium-cpt' ).'</option>
		    <option value="right"'.$selected_3.'>'.__( "Right", 'magnium-cpt' ).'</option>
		    <option value="disable"'.$selected_4.'>'.__( "Disable sidebar", 'magnium-cpt' ).'</option>
		</select></p>';

	}

	function portfolio_settings_save_postdata( $post_id ) {

		/*
		* We need to verify this came from the our screen and with proper authorization,
		* because save_post can be triggered at other times.
		*/

		// Check if our nonce is set.
		if ( ! isset( $_POST['portfolio_settings_inner_box_nonce'] ) )
		return $post_id;

		$nonce = $_POST['portfolio_settings_inner_box_nonce'];

		// Verify that the nonce is valid.
		if ( ! wp_verify_nonce( $nonce, 'portfolio_settings_inner_box' ) )
		  return $post_id;

		// If this is an autosave, our form has not been submitted, so we don't want to do anything.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) 
		  return $post_id;

		// Check the user's permissions.
		if ( 'page' == $_POST['post_type'] ) {

		if ( ! current_user_can( 'edit_page', $post_id ) )
		    return $post_id;

		} else {

		if ( ! current_user_can( 'edit_post', $post_id ) )
		    return $post_id;
		}

		// Sanitize user input.
		if(!isset($_POST['page_fullwidth'])) $_POST['page_fullwidth'] = false;

		$mydata = sanitize_text_field( $_POST['page_fullwidth'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_page_fullwidth_value', $mydata );

		// Sanitize user input.
		if(!isset($_POST['portfolio_hide_details'])) $_POST['portfolio_hide_details'] = false;

		$mydata = sanitize_text_field( $_POST['portfolio_hide_details'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_hide_details_value', $mydata );

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_url'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_url_value', $mydata );

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_brand'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_brand_value', $mydata );

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_brand_url'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_brand_url_value', $mydata );

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_display_type'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_display_type_value', $mydata );
		
		if(!isset($_POST['portfolio_disableslider'])) $_POST['portfolio_disableslider'] = false;

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_disableslider'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_disableslider_value', $mydata );
		
		if(!isset($_POST['portfolio_fullwidthslider'])) $_POST['portfolio_fullwidthslider'] = false;

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_fullwidthslider'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_fullwidthslider_value', $mydata );

		if(!isset($_POST['portfolio_hide_1st_image_from_slider'])) $_POST['portfolio_hide_1st_image_from_slider'] = false;

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_hide_1st_image_from_slider'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_hide_1st_image_from_slider_value', $mydata );

		if(!isset($_POST['portfolio_socialshare_disable'])) $_POST['portfolio_socialshare_disable'] = false;

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_socialshare_disable'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_socialshare_disable_value', $mydata );

		if(!isset($_POST['portfolio_original_image_sizes'])) $_POST['portfolio_original_image_sizes'] = false;

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_original_image_sizes'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_original_image_sizes_value', $mydata );

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_sidebarposition'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_sidebarposition_value', $mydata );

		// Sanitize user input.
		$mydata = sanitize_text_field( $_POST['portfolio_titleposition'] );

		// Update the meta field in the database.
		update_post_meta( $post_id, '_portfolio_titleposition_value', $mydata );

	}
	add_action( 'save_post', 'portfolio_settings_save_postdata' );

	// Multi images for portfolio 
	function magnium_image_cpt(){
	    $cpts = array('mgt_portfolio');
	    return $cpts;
	}
	add_filter('images_cpt','magnium_image_cpt');

	/**
	 * Disable VIEW buttons for custom post types that does not have single pages
	 **/
	function magnium_hide_view_button() {
	 	$hide_view_in_post_types = Array('mgt_portfolio', 'mgt_clients_reviews');
		$current_screen = get_current_screen();
		
		foreach ( $hide_view_in_post_types as $post_type ) {
			if( $current_screen->post_type === $post_type ) {
			echo '<style>#edit-slug-box{display: none;}</style>';
			}
		}
		return; 
	}
	add_action( 'admin_head', 'magnium_hide_view_button' );
	 
	/**
	* Removes the 'view' link in the admin bar
	*
	*/
	function magnium_remove_view_button_admin_bar() {
	 
		global $wp_admin_bar;
		$hide_view_in_post_types = Array('mgt_clients_reviews');
		foreach ( $hide_view_in_post_types as $post_type ) {
			if( get_post_type() === $post_type){
				$wp_admin_bar->remove_menu('view');
			}
		}
	}
	add_action( 'wp_before_admin_bar_render', 'magnium_remove_view_button_admin_bar' );
	 
	function magnium_remove_view_row_action( $actions ) {
	 	$hide_view_in_post_types = Array('mgt_clients_reviews');
		foreach ( $hide_view_in_post_types as $post_type ) {
			if( get_post_type() === $post_type ){
				unset( $actions['view'] );
			}
		}
		return $actions;
	 
	}
	add_filter( 'post_row_actions', 'magnium_remove_view_row_action', 10, 1 );
}

/**
 * Load theme custom shortcodes.
*/
require plugin_dir_path( __FILE__ ).'inc/theme-shortcodes.php';
