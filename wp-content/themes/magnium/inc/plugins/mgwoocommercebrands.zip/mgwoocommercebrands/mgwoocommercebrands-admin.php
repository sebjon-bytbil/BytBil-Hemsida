<?php
/**
 * Admin setting class
 *
 * @author  MagniumThemes
 * @package magniumthemes.com
 */


if ( ! class_exists( 'mgwoocommercebrandsadmin' ) ) {
	/**
	 * Admin class.
	 * The class manage all the admin behaviors.
	 *
	 * @since 1.0.0
	 */
	class mgwoocommercebrandsadmin {

		public function __construct() {

			//Actions
			add_action( 'init', array( $this, 'init' ) );

			add_action( 'woocommerce_settings_tabs_mgwoocommercebrands', array( $this, 'print_plugin_options' ) );
			add_action( 'woocommerce_update_options_mgwoocommercebrands', array( $this, 'update_options' ) );

			//Filters
			add_filter( 'woocommerce_settings_tabs_array', array( $this, 'add_tab_woocommerce' ), 30 );

		}


		/**
		 * Init method:
		 *  - default options
		 *
		 * @access public
		 * @since  1.0.0
		 */
		public function init() {
			$this->options = $this->_initOptions();
			//$this->_default_options();
		}


		/**
		 * Update plugin options.
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function update_options() {
			foreach ( $this->options as $option ) {
				woocommerce_update_options( $option );
			}
		}


		/**
		 * Add Magnifier's tab to Woocommerce -> Settings page
		 *
		 * @access public
		 *
		 * @param array $tabs
		 *
		 * @return array
		 */
		public function add_tab_woocommerce( $tabs ) {
			$tabs['mgwoocommercebrands'] = __( 'Brands settings', 'mgwoocommercebrands' );

			return $tabs;
		}


		/**
		 * Print all plugin options.
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_plugin_options() {
			?>
			<div class="subsubsub_section">

				<?php foreach ( $this->options as $id => $tab ) : ?>
					<!-- tab #<?php echo $id ?> -->
					<div class="section" id="mgwoocommercebrands_<?php echo $id ?>">
						<?php woocommerce_admin_fields( $this->options[$id] ) ?>
					</div>
				<?php endforeach ?>
			</div>
		<?php
		}


		/**
		 * Initialize the options
		 *
		 * @access protected
		 * @return array
		 * @since  1.0.0
		 */
		protected function _initOptions() {
			$options = array(
				'general' => array(
					array( 'title' => __( 'General Options', 'mgwoocommercebrands' ),
						   'type'  => 'title',
						   'desc'  => '',
						   'id'    => 'mgwoocommercebrands_options' ),
					array(
						'title'    => __( 'Brand name show on', 'mgwoocommercebrands' ),
						'id'       => 'mgb_where_show',
						'default'  => '0',
						'type'     => 'radio',
						'desc_tip' => __( 'Please select where you want show Brand name.', 'mgwoocommercebrands' ),
						'options'  => array(
							'0' => __( 'Both categories and product detail page', 'mgwoocommercebrands' ),
							'1' => __( 'Only categories ', 'mgwoocommercebrands' ),
							'2' => __( 'Only product detail', 'mgwoocommercebrands' )
						),
					),
					array(
						'title'    => __( 'Brand title', 'mgwoocommercebrands' ),
						'id'       => 'mgb_brand_title',
						'default'  => 'Brand:',
						'type'     => 'text',
						'desc_tip' => __( 'Leave empty if you dont want to show brand title before brand name(s)', 'mgwoocommercebrands' ),
						'options'  => array(
							'0' => __( 'Show as brand(s) title', 'mgwoocommercebrands' ),
							'1' => __( 'Show as brand(s) image', 'mgwoocommercebrands' )
						),
					),
					
					array(
						'title'    => __( 'Brand display type on product detail page', 'mgwoocommercebrands' ),
						'id'       => 'mgb_show_image',
						'default'  => '0',
						'type'     => 'radio',
						'desc_tip' => __( 'Please check if you want to see brand image instead of title', 'mgwoocommercebrands' ),
						'options'  => array(
							'0' => __( 'Show as brand(s) title', 'mgwoocommercebrands' ),
							'1' => __( 'Show as brand(s) image', 'mgwoocommercebrands' )
						),
					),
					
					array( 'type' => 'sectionend', 'id' => 'mgwoocommercebrands_options' ),

					array( 'title' => __( 'Product Details Page', 'mgwoocommercebrands' ),
						   'type'  => 'title',
						   'desc'  => '',
						   'id'    => 'mgwoocommercebrands_detail_product' ),
					array(
						'title'    => __( 'Brand display position', 'mgwoocommercebrands' ),
						'id'       => 'mgb_detail_position',
						'default'  => '0',
						'type'     => 'radio',
						'desc_tip' => __( 'Please choose postion where brand show on product details page.', 'mgwoocommercebrands' ),
						'options'  => array(
							'0' => __( 'Above tabs area', 'mgwoocommercebrands' ),
							'1' => __( 'Below tabs area', 'mgwoocommercebrands' ),
							'2' => __( 'Above short description', 'mgwoocommercebrands' ),
							'3' => __( 'Below short description', 'mgwoocommercebrands' ),
							'4' => __( 'Above Add to cart', 'mgwoocommercebrands' ),
							'5' => __( 'Below Add to cart', 'mgwoocommercebrands' ),
							'6' => __( 'Above Categories list', 'mgwoocommercebrands' ),
							'7' => __( 'Below Categories list', 'mgwoocommercebrands' ),
							'8' => __( 'Inside product meta', 'mgwoocommercebrands' )
						),
					),

					array( 'type' => 'sectionend', 'id' => 'mgwoocommercebrands_detail_product' ),

					array( 'title' => __( 'Product Category', 'mgwoocommercebrands' ),
						   'type'  => 'title',
						   'desc'  => '',
						   'id'    => 'mgwoocommercebrands_product_category' ),
					array(
						'title'    => __( 'Brand display position on category', 'mgwoocommercebrands' ),
						'id'       => 'mgb_category_position',
						'default'  => '0',
						'type'     => 'radio',
						'desc_tip' => __( 'Please choose postion where brand show on category products.', 'mgwoocommercebrands' ),
						'options'  => array(
							'0' => __( 'Above price', 'mgwoocommercebrands' ),
							'1' => __( 'Above title', 'mgwoocommercebrands' ),
							'4' => __( 'Below title', 'mgwoocommercebrands' ),
							'2' => __( 'Above Add to Cart', 'mgwoocommercebrands' ),
							'3' => __( 'Below Add to Cart', 'mgwoocommercebrands' )
							
						),
					),
					array( 'type' => 'sectionend', 'id' => 'mgwoocommercebrands_product_category' )

				)
			);

			return apply_filters( 'mgwoocommercebrands_tab_options', $options );
		}
	}
}
